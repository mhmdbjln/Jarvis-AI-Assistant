"""Command-line entry point for Jarvis."""

import sys

from app.core.agent import JarvisAgent


EXIT_COMMANDS = {"exit", "quit"}


def main() -> int:
    try:
        agent = JarvisAgent()
        conversation_id = agent.history_store.create_conversation()
    except Exception as error:
        print(f"Failed to start Jarvis: {error}", file=sys.stderr)
        return 1

    print("Jarvis is ready. Type 'exit' or 'quit' to leave.")

    try:
        while True:
            user_input = input("You: ").strip()

            if not user_input:
                continue

            if user_input.lower() in EXIT_COMMANDS:
                print("Goodbye.")
                return 0

            try:
                response = agent.process(
                    user_message=user_input,
                    conversation_id=conversation_id,
                )
            except Exception as error:
                print(f"Request failed: {error}")
                continue

            print(f"Jarvis: {response}")

    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye.")
        return 0


if __name__ == "__main__":
    sys.exit(main())