import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ReminderStore:
    """Stores and retrieves reminders using SQLite."""

    def __init__(self, db_path: str | None = None) -> None:
        if db_path is None:
            storage_dir = Path.home() / ".jarvis"
            storage_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(storage_dir / "memory.db")

        self.db_path = db_path

        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS reminders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    due_at TEXT,
                    is_done INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                )
                """
            )

    def add_reminder(self, text: str, due_at: str | None = None) -> int:
        """
        Add a new reminder.

        Args:
            text: The content of the reminder.
            due_at: Optional free-text description of when it's due
                (e.g. "tomorrow at 10am", "2026-09-20").

        Returns:
            The id of the newly created reminder.
        """

        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                """
                INSERT INTO reminders (text, due_at, is_done, created_at)
                VALUES (?, ?, 0, ?)
                """,
                (
                    text,
                    due_at,
                    datetime.now(timezone.utc).isoformat(),
                ),
            )

            return cursor.lastrowid

    def list_reminders(self, include_done: bool = False) -> list[dict[str, Any]]:
        """
        List reminders.

        Args:
            include_done: If True, also include completed reminders.
        """

        query = "SELECT id, text, due_at, is_done FROM reminders"

        if not include_done:
            query += " WHERE is_done = 0"

        query += " ORDER BY id ASC"

        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(query)
            rows = cursor.fetchall()

        return [
            {
                "id": row[0],
                "text": row[1],
                "due_at": row[2],
                "is_done": bool(row[3]),
            }
            for row in rows
        ]

    def complete_reminder(self, reminder_id: int) -> bool:
        """
        Mark a reminder as done.

        Returns:
            True if a reminder was updated, False if no matching id existed.
        """

        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                "UPDATE reminders SET is_done = 1 WHERE id = ?",
                (reminder_id,),
            )

            return cursor.rowcount > 0