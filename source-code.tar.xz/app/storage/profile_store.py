import sqlite3
from datetime import datetime, timezone
from pathlib import Path


class ProfileStore:
    """Stores durable facts about the user across all conversations."""

    def __init__(self, db_path: str | None = None) -> None:
        if db_path is None:
            storage_dir = Path.home() / ".jarvis"
            storage_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(storage_dir / "memory.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS profile_facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fact TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )

    def add_fact(self, fact: str) -> int:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                "INSERT INTO profile_facts (fact, created_at) VALUES (?, ?)",
                (fact, datetime.now(timezone.utc).isoformat()),
            )
            return cursor.lastrowid

    def get_facts(self) -> list[str]:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute("SELECT fact FROM profile_facts ORDER BY id ASC")
            return [row[0] for row in cursor.fetchall()]

    def clear_facts(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute("DELETE FROM profile_facts")