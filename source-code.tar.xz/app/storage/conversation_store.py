import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ConversationStore:
    """Stores multiple conversations, each with its own message history."""

    def __init__(self, db_path: str | None = None) -> None:
        if db_path is None:
            storage_dir = Path.home() / ".jarvis"
            storage_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(storage_dir / "memory.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (conversation_id) REFERENCES conversations (id)
                )
                """
            )

    def create_conversation(self, title: str = "New Chat") -> int:
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                "INSERT INTO conversations (title, created_at, updated_at) VALUES (?, ?, ?)",
                (title, now, now),
            )
            return cursor.lastrowid

    def get_conversation(self, conversation_id: int) -> dict[str, Any] | None:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                "SELECT id, title, created_at, updated_at FROM conversations WHERE id = ?",
                (conversation_id,),
            )
            row = cursor.fetchone()

        if row is None:
            return None

        return {"id": row[0], "title": row[1], "created_at": row[2], "updated_at": row[3]}

    def list_conversations(self) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                "SELECT id, title, updated_at FROM conversations ORDER BY updated_at DESC"
            )
            rows = cursor.fetchall()

        return [{"id": r[0], "title": r[1], "updated_at": r[2]} for r in rows]

    def get_latest_conversation_id(self) -> int | None:
        conversations = self.list_conversations()
        return conversations[0]["id"] if conversations else None

    def rename_conversation(self, conversation_id: int, title: str) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                "UPDATE conversations SET title = ? WHERE id = ?", (title, conversation_id)
            )

    def delete_conversation(self, conversation_id: int) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                "DELETE FROM messages WHERE conversation_id = ?", (conversation_id,)
            )
            connection.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))

    def add_message(self, conversation_id: int, role: str, content: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                """
                INSERT INTO messages (conversation_id, role, content, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (conversation_id, role, content, now),
            )
            connection.execute(
                "UPDATE conversations SET updated_at = ? WHERE id = ?",
                (now, conversation_id),
            )

    def get_history(self, conversation_id: int, limit: int = 20) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                """
                SELECT role, content FROM messages
                WHERE conversation_id = ?
                ORDER BY id DESC LIMIT ?
                """,
                (conversation_id, limit),
            )
            rows = cursor.fetchall()

        rows.reverse()
        return [{"role": role, "content": content} for role, content in rows]

    def get_full_history(self, conversation_id: int, limit: int = 500) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as connection:
            cursor = connection.execute(
                """
                SELECT role, content, created_at FROM messages
                WHERE conversation_id = ?
                ORDER BY id DESC LIMIT ?
                """,
                (conversation_id, limit),
            )
            rows = cursor.fetchall()

        rows.reverse()
        return [
            {"role": role, "content": content, "created_at": created_at}
            for role, content, created_at in rows
        ]

    def clear_all(self) -> None:
        with sqlite3.connect(self.db_path) as connection:
            connection.execute("DELETE FROM messages")
            connection.execute("DELETE FROM conversations")