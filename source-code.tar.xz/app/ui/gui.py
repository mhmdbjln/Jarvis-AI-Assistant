import subprocess
import threading
import traceback
import queue
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, font as tkfont, messagebox, simpledialog
from typing import Any

import psutil
from AppKit import NSStatusBar, NSMenu, NSMenuItem, NSVariableStatusItemLength
from Foundation import NSObject

from app.core.agent import JarvisAgent
from app.tools.reminders import list_reminders
from app.ai.voice import (
    TranscriptionError,
    VoiceRecorder,
    shutdown_speech,
    speak,
    transcribe,
)
from app.ai.wake_word import WakeWordListener


SIGNAL_FILE = Path.home() / ".jarvis" / "toggle_signal"

BG_DARK = "#0a0e17"
SIDEBAR_BG = "#0d1220"
CARD_BG = "#131a2b"
HEADER_BG = "#0d1420"
BORDER_COLOR = "#1f2940"
USER_BUBBLE = "#3a4a63"
ASSISTANT_BUBBLE = "#131a2b"
TEXT_COLOR = "#e8ecf5"
MUTED_COLOR = "#7c88a3"
ACCENT_COLOR = "#3d8bff"
ACCENT_DIM = "#1a4fd6"
ONLINE_COLOR = "#3ddc84"
INPUT_BG = "#0f1626"
PILL_BG = "#101a30"
NAV_ACTIVE_BG = "#1c3a66"
DANGER_COLOR = "#ff5c5c"

WINDOW_W = 1312
WINDOW_H = 1198

POLL_MS = 100
WAKE_RECORDING_MS = 5000

# After every voice turn the wake word listener re-opens but ignores the mic for
# this long, so the tail of Jarvis's own voice (or stale audio) can never count
# as a new "Hey Jarvis". Re-opening the listener never starts a recording.
RESUME_GUARD_SECONDS = 1.5

VOICE_STANDBY = "STANDBY"        # listening only for a fresh "Hey Jarvis"
VOICE_RECORDING = "RECORDING"    # capturing one command
VOICE_PROCESSING = "PROCESSING"  # transcribing / waiting for the agent
VOICE_SPEAKING = "SPEAKING"      # Jarvis is talking

QUICK_ACTIONS = [
    ("\U0001F4E6", "Open an app", "prefill", "Open "),
    ("\U0001F50D", "Search the web", "prefill", "Search the web for "),
    ("\U0001F5A5", "System info", "submit",
     "What is my battery level, CPU usage, and disk space?"),
    ("\u2022\u2022\u2022", "More tools", "view", "Tools"),
]

NAV_ITEMS = [
    ("\U0001F4AC", "Chat"),
    ("\U0001F527", "Tools"),
    ("\u2699", "Settings"),
    ("\U0001F553", "Chats"),
]


def rounded_rect(canvas, x1, y1, x2, y2, radius=14, **kwargs):
    points = [
        x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
        x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
        x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


def draw_logo(canvas, cx, cy, radius, color=ACCENT_COLOR, dim=ACCENT_DIM):
    canvas.create_oval(cx - radius, cy - radius, cx + radius, cy + radius, outline=dim, width=2, fill="")
    canvas.create_oval(
        cx - radius * 0.65, cy - radius * 0.65, cx + radius * 0.65, cy + radius * 0.65,
        outline=color, width=2, fill="",
    )
    canvas.create_oval(
        cx - radius * 0.3, cy - radius * 0.3, cx + radius * 0.3, cy + radius * 0.3,
        fill=color, outline="",
    )


def get_macos_version() -> str:
    try:
        result = subprocess.run(["sw_vers", "-productVersion"], capture_output=True, text=True)
        return f"macOS {result.stdout.strip()}"
    except Exception:
        return "macOS"


def get_chip_name() -> str:
    try:
        result = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True)
        name = result.stdout.strip()
        if name:
            return name
        result = subprocess.run(["sysctl", "-n", "hw.model"], capture_output=True, text=True)
        return result.stdout.strip() or "Apple Silicon"
    except Exception:
        return "Apple Silicon"


def get_ram_gb() -> str:
    try:
        total_gb = psutil.virtual_memory().total / (1024**3)
        return f"{total_gb:.1f} GB RAM"
    except Exception:
        return ""


class JarvisGUI:
    """
    Jarvis chat window: multi-chat sessions, header actions, and voice.

    Threading rule: ONLY the main thread touches Tkinter. Every background
    thread (agent, transcription, speech, wake word) communicates solely by
    calling self._post(), which puts an event on a thread-safe queue that
    _poll_queue() drains on the main thread.
    """

    def __init__(self) -> None:
        self.agent = JarvisAgent()
        self._events: "queue.Queue[tuple[str, Any]]" = queue.Queue()
        self._closing = False
        self._is_thinking = False
        self._active_nav = "Chat"
        self._always_on_top = True
        self._is_recording = False
        self._is_speaking = False
        self._transcribing = False
        self._recording_token = 0
        self._voice_active = False
        self._wake_listener_started = False
        self.recorder = VoiceRecorder()
        self.wake_listener = WakeWordListener(
            self._on_wake_word, on_error=self._on_wake_error
        )
        self._last_signal_mtime = self._read_signal_mtime()

        self.current_conversation_id = self.agent.history_store.get_latest_conversation_id()
        if self.current_conversation_id is None:
            self.current_conversation_id = self.agent.history_store.create_conversation()

        self.root = tk.Tk()
        self.root.title("Jarvis")
        self.root.configure(bg=BG_DARK)
        self.root.attributes("-topmost", True)
        self.root.geometry(f"{WINDOW_W}x{WINDOW_H}+120+40")
        self.root.minsize(900, 640)
        self.root.withdraw()

        # Show callback exceptions (button clicks, etc.) as a visible
        # dialog instead of a silent system beep.
        self.root.report_callback_exception = self._report_callback_exception

        self._load_fonts()
        self._build_layout()
        self._load_conversation(self.current_conversation_id)

        self.root.after(POLL_MS, self._poll_queue)
        self.root.after(300, self._poll_signal_file)

    def _report_callback_exception(self, exc_type, exc_value, exc_tb) -> None:
        error_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        print(error_text)
        if not self._closing:
            messagebox.showerror("Jarvis encountered an error", error_text[-1800:])

    @property
    def voice_state(self) -> str:
        """STANDBY / RECORDING / PROCESSING / SPEAKING, derived from the flags."""
        if self._is_recording:
            return VOICE_RECORDING
        if self._is_speaking:
            return VOICE_SPEAKING
        if self._is_thinking or self._transcribing:
            return VOICE_PROCESSING
        return VOICE_STANDBY

    # ---- thread-safe event bridge ----
    def _post(self, kind: str, payload: Any = None) -> None:
        """Safe to call from ANY thread. Never touches Tkinter."""
        if self._closing:
            return
        self._events.put((kind, payload))

    def _poll_queue(self) -> None:
        """Main-thread only: drain the event queue."""
        if self._closing:
            return

        try:
            while True:
                kind, payload = self._events.get_nowait()
                try:
                    self._handle_event(kind, payload)
                except Exception:
                    traceback.print_exc()
        except queue.Empty:
            pass

        if not self._closing:
            self.root.after(POLL_MS, self._poll_queue)

    def _handle_event(self, kind: str, payload: Any) -> None:
        if self._closing:
            return

        if kind == "agent_response":
            self._on_agent_response(payload)
        elif kind == "transcript":
            self._transcribing = False
            if not self._submit_message(payload, speak_response=True):
                self._end_voice_session()
        elif kind == "transcription_empty":
            self._transcribing = False
            self._end_voice_session()
        elif kind == "transcription_error":
            self._transcribing = False
            self._add_bubble(f"I couldn't understand the audio: {payload}", is_user=False)
            self._end_voice_session()
        elif kind == "wake":
            self._start_wake_recording()
        elif kind == "wake_error":
            self._add_bubble(f"Wake word is unavailable: {payload}", is_user=False)
        elif kind == "speech_done":
            self._is_speaking = False
            self._end_voice_session()

    # ---- lifecycle helpers ----
    def _read_signal_mtime(self) -> float:
        try:
            return SIGNAL_FILE.stat().st_mtime
        except FileNotFoundError:
            return 0.0

    def _poll_signal_file(self) -> None:
        if self._closing:
            return

        current_mtime = self._read_signal_mtime()
        if current_mtime != self._last_signal_mtime:
            self._last_signal_mtime = current_mtime
            self.toggle()
        self.root.after(300, self._poll_signal_file)

    def _load_fonts(self) -> None:
        self.font_brand = tkfont.Font(family="Helvetica Neue", size=20, weight="bold")
        self.font_brand_sub = tkfont.Font(family="Helvetica Neue", size=11)
        self.font_nav = tkfont.Font(family="Helvetica Neue", size=13)
        self.font_card_title = tkfont.Font(family="Helvetica Neue", size=12, weight="bold")
        self.font_card_sub = tkfont.Font(family="Helvetica Neue", size=11)
        self.font_quote = tkfont.Font(family="Helvetica Neue", size=12, slant="italic")
        self.font_title = tkfont.Font(family="Helvetica Neue", size=17, weight="bold")
        self.font_status = tkfont.Font(family="Helvetica Neue", size=11)
        self.font_body = tkfont.Font(family="Helvetica Neue", size=13)
        self.font_time = tkfont.Font(family="Helvetica Neue", size=9)
        self.font_pill = tkfont.Font(family="Helvetica Neue", size=11)
        self.font_section = tkfont.Font(family="Helvetica Neue", size=15, weight="bold")
        self.font_tool_name = tkfont.Font(family="Helvetica Neue", size=13, weight="bold")

    # ---- layout ----
    def _build_layout(self) -> None:
        container = tk.Frame(self.root, bg=BG_DARK)
        container.pack(fill=tk.BOTH, expand=True)

        self._build_sidebar(container)
        tk.Frame(container, bg=BORDER_COLOR, width=1).pack(side=tk.LEFT, fill=tk.Y)
        self._build_main(container)

    def _build_sidebar(self, parent) -> None:
        sidebar = tk.Frame(parent, bg=SIDEBAR_BG, width=300)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        brand_row = tk.Frame(sidebar, bg=SIDEBAR_BG)
        brand_row.pack(fill=tk.X, padx=24, pady=(28, 20))

        logo_canvas = tk.Canvas(brand_row, width=56, height=56, bg=SIDEBAR_BG, highlightthickness=0)
        logo_canvas.pack(side=tk.LEFT)
        draw_logo(logo_canvas, 28, 28, 26)

        brand_text = tk.Frame(brand_row, bg=SIDEBAR_BG)
        brand_text.pack(side=tk.LEFT, padx=(14, 0))

        tk.Label(brand_text, text="J A R V I S", fg=TEXT_COLOR, bg=SIDEBAR_BG, font=self.font_brand).pack(anchor="w")
        tk.Label(brand_text, text="Your AI Assistant", fg=MUTED_COLOR, bg=SIDEBAR_BG, font=self.font_brand_sub).pack(anchor="w")

        nav_frame = tk.Frame(sidebar, bg=SIDEBAR_BG)
        nav_frame.pack(fill=tk.X, padx=16, pady=(4, 0))

        self._nav_canvases = {}
        for icon, label in NAV_ITEMS:
            row_canvas = tk.Canvas(nav_frame, height=44, bg=SIDEBAR_BG, highlightthickness=0, cursor="pointinghand")
            row_canvas.pack(fill=tk.X, pady=3)
            row_canvas.bind(
                "<Configure>",
                lambda event, c=row_canvas, i=icon, l=label: self._draw_nav_row(c, i, l),
            )
            row_canvas.bind("<Button-1>", lambda event, l=label: self._switch_view(l))
            self._nav_canvases[label] = row_canvas

        tk.Frame(sidebar, bg=BORDER_COLOR, height=1).pack(fill=tk.X, padx=16, pady=16)

        self._build_status_card(sidebar)
        self._build_system_card(sidebar)

        tk.Frame(sidebar, bg=SIDEBAR_BG).pack(fill=tk.BOTH, expand=True)

        quote_frame = tk.Frame(sidebar, bg=SIDEBAR_BG)
        quote_frame.pack(fill=tk.X, padx=24, pady=24)

        tk.Label(
            quote_frame, text='"The best way to predict\nthe future is to create it."',
            fg=MUTED_COLOR, bg=SIDEBAR_BG, font=self.font_quote, justify=tk.LEFT,
        ).pack(anchor="w")
        tk.Label(quote_frame, text="\u2014 JARVIS", fg=MUTED_COLOR, bg=SIDEBAR_BG, font=self.font_card_sub).pack(anchor="w", pady=(4, 0))

    def _draw_nav_row(self, canvas, icon, label) -> None:
        canvas.delete("all")
        width = canvas.winfo_width()
        if width <= 1:
            width = 268

        is_active = label == self._active_nav
        if is_active:
            rounded_rect(canvas, 0, 2, width, 42, radius=10, fill=NAV_ACTIVE_BG, outline="")

        text_color = TEXT_COLOR if is_active else MUTED_COLOR
        canvas.create_text(16, 22, text=icon, anchor="w", font=("Helvetica Neue", 14), fill=text_color)
        canvas.create_text(46, 22, text=label, anchor="w", font=self.font_nav, fill=text_color)

    def _build_status_card(self, sidebar) -> None:
        card = tk.Frame(sidebar, bg=CARD_BG)
        card.pack(fill=tk.X, padx=16, pady=(0, 10), ipady=10)

        row = tk.Frame(card, bg=CARD_BG)
        row.pack(fill=tk.X, padx=14, pady=(6, 2))

        self.sidebar_dot = tk.Label(row, text="\u25CF", fg=ONLINE_COLOR, bg=CARD_BG, font=("Helvetica Neue", 10))
        self.sidebar_dot.pack(side=tk.LEFT)

        tk.Label(row, text=" JARVIS is online", fg=TEXT_COLOR, bg=CARD_BG, font=self.font_card_title).pack(side=tk.LEFT)
        tk.Label(card, text="Ready to help you", fg=MUTED_COLOR, bg=CARD_BG, font=self.font_card_sub).pack(anchor="w", padx=14)

    def _build_system_card(self, sidebar) -> None:
        card = tk.Frame(sidebar, bg=CARD_BG)
        card.pack(fill=tk.X, padx=16, pady=(0, 10), ipady=10)

        row = tk.Frame(card, bg=CARD_BG)
        row.pack(fill=tk.X, padx=14, pady=(6, 2))

        tk.Label(row, text="\U0001F5A5", fg=MUTED_COLOR, bg=CARD_BG, font=("Helvetica Neue", 12)).pack(side=tk.LEFT)
        tk.Label(row, text=" System Info", fg=TEXT_COLOR, bg=CARD_BG, font=self.font_card_title).pack(side=tk.LEFT)

        for line in (get_macos_version(), get_chip_name(), get_ram_gb()):
            if line:
                tk.Label(card, text=line, fg=MUTED_COLOR, bg=CARD_BG, font=self.font_card_sub).pack(anchor="w", padx=14)

    def _build_main(self, parent) -> None:
        main = tk.Frame(parent, bg=BG_DARK)
        main.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._build_header(main)

        self.view_container = tk.Frame(main, bg=BG_DARK)
        self.view_container.pack(fill=tk.BOTH, expand=True)

        self.views: dict[str, tk.Frame] = {}
        self._build_chat_view()
        self._build_tools_view()
        self._build_settings_view()
        self._build_chats_view()

        self.input_bar_frame = tk.Frame(main, bg=BG_DARK)
        self._build_input_bar(self.input_bar_frame)

        self._switch_view("Chat")

        self.root.bind("<Escape>", lambda event: self.hide())
        # Closing the window only hides Jarvis; real exit is via shutdown().
        self.root.protocol("WM_DELETE_WINDOW", self.hide)

    def _switch_view(self, label: str) -> None:
        self._active_nav = label
        for item_label, canvas in self._nav_canvases.items():
            icon = next(i for i, l in NAV_ITEMS if l == item_label)
            self._draw_nav_row(canvas, icon, item_label)

        for name, frame in self.views.items():
            frame.pack_forget()

        self.views[label].pack(fill=tk.BOTH, expand=True)

        if label == "Chat":
            self.input_bar_frame.pack(fill=tk.X, side=tk.BOTTOM)
        else:
            self.input_bar_frame.pack_forget()

        if label == "Chats":
            self._refresh_chats_view()

    def _build_header(self, parent) -> None:
        header = tk.Frame(parent, bg=HEADER_BG, height=84)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        logo_canvas = tk.Canvas(header, width=48, height=48, bg=HEADER_BG, highlightthickness=0)
        logo_canvas.pack(side=tk.LEFT, padx=(24, 12), pady=18)
        draw_logo(logo_canvas, 24, 24, 22)

        text_frame = tk.Frame(header, bg=HEADER_BG)
        text_frame.pack(side=tk.LEFT, pady=18)

        tk.Label(text_frame, text="Jarvis", fg=TEXT_COLOR, bg=HEADER_BG, font=self.font_title).pack(anchor="w")

        status_row = tk.Frame(text_frame, bg=HEADER_BG)
        status_row.pack(anchor="w")

        self.status_dot = tk.Label(status_row, text="\u25CF", fg=ONLINE_COLOR, bg=HEADER_BG, font=("Helvetica Neue", 9))
        self.status_dot.pack(side=tk.LEFT)

        self.status_label = tk.Label(status_row, text=" Online", fg=MUTED_COLOR, bg=HEADER_BG, font=self.font_status)
        self.status_label.pack(side=tk.LEFT)

        icons_frame = tk.Frame(header, bg=HEADER_BG)
        icons_frame.pack(side=tk.RIGHT, padx=24)

        self.sun_circle = self._make_icon_button(icons_frame, "\u2600", self._toggle_always_on_top)
        self._make_icon_button(icons_frame, "\U0001F514", self._show_reminders)
        self._make_icon_button(icons_frame, "\U0001F464", lambda: self._switch_view("Settings"))

        tk.Frame(parent, bg=BORDER_COLOR, height=1).pack(fill=tk.X)

    def _make_icon_button(self, parent, icon, command):
        circle = tk.Canvas(parent, width=36, height=36, bg=HEADER_BG, highlightthickness=0, cursor="pointinghand")
        circle.pack(side=tk.LEFT, padx=6)
        circle.create_oval(2, 2, 34, 34, outline=BORDER_COLOR, width=1, tags="ring")
        circle.create_text(18, 18, text=icon, font=("Helvetica Neue", 13), fill=MUTED_COLOR, tags="glyph")
        circle.bind("<Button-1>", lambda event: command())
        return circle

    def _toggle_always_on_top(self) -> None:
        self._always_on_top = not self._always_on_top
        self.root.attributes("-topmost", self._always_on_top)
        color = ACCENT_COLOR if self._always_on_top else MUTED_COLOR
        self.sun_circle.itemconfig("glyph", fill=color)
        self.sun_circle.itemconfig("ring", outline=ACCENT_DIM if self._always_on_top else BORDER_COLOR)

    def _show_reminders(self) -> None:
        try:
            reminders_text = list_reminders()
        except Exception as error:
            reminders_text = f"Could not load reminders: {error}"
        messagebox.showinfo("Reminders", reminders_text)

    # ---- Chat view ----
    def _build_chat_view(self) -> None:
        chat_frame = tk.Frame(self.view_container, bg=BG_DARK)
        self.views["Chat"] = chat_frame

        self.canvas = tk.Canvas(chat_frame, bg=BG_DARK, highlightthickness=0)
        scrollbar = tk.Scrollbar(chat_frame, command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)

        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.messages_frame = tk.Frame(self.canvas, bg=BG_DARK)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.messages_frame, anchor="nw")

        self.messages_frame.bind("<Configure>", lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfig(self.canvas_window, width=event.width))

    def _build_input_bar(self, parent) -> None:
        tk.Frame(parent, bg=BORDER_COLOR, height=1).pack(fill=tk.X)

        input_bar = tk.Frame(parent, bg=BG_DARK)
        input_bar.pack(fill=tk.X, padx=20, pady=18)

        input_wrap = tk.Frame(input_bar, bg=INPUT_BG)
        input_wrap.pack(fill=tk.X, side=tk.LEFT, expand=True, ipady=6)

        attach_label = tk.Label(input_wrap, text="\U0001F4CE", bg=INPUT_BG, fg=MUTED_COLOR, font=("Helvetica Neue", 13), cursor="pointinghand")
        attach_label.pack(side=tk.LEFT, padx=(14, 6))
        attach_label.bind("<Button-1>", lambda event: self._attach_file())

        self.mic_label = tk.Label(input_wrap, text="\U0001F3A4", bg=INPUT_BG, fg=MUTED_COLOR, font=("Helvetica Neue", 13), cursor="pointinghand")
        self.mic_label.pack(side=tk.LEFT, padx=(0, 6))
        self.mic_label.bind("<Button-1>", lambda event: self._toggle_recording())

        self.entry = tk.Entry(input_wrap, font=self.font_body, bg=INPUT_BG, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, relief=tk.FLAT)
        self.entry.pack(fill=tk.X, expand=True, padx=(0, 14), pady=6)
        self.entry.bind("<Return>", self._on_submit)

        send_canvas = tk.Canvas(input_bar, width=44, height=44, bg=BG_DARK, highlightthickness=0, cursor="pointinghand")
        send_canvas.pack(side=tk.LEFT, padx=(10, 0))
        send_canvas.create_oval(1, 1, 43, 43, fill=ACCENT_COLOR, outline="")
        send_canvas.create_text(22, 22, text="\u27A4", fill="white", font=("Helvetica", 15))
        send_canvas.bind("<Button-1>", self._on_submit)

    def _attach_file(self) -> None:
        path = filedialog.askopenfilename(title="Choose a file for Jarvis to read")
        if not path:
            return
        self._submit_message(f"Summarize the file at {path}", speak_response=False)

    # ---- Voice session helpers (main thread only) ----
    def _begin_voice_session(self) -> None:
        self._voice_active = True
        if self._wake_listener_started:
            self.wake_listener.pause()

    def _end_voice_session(self) -> None:
        """
        Return to STANDBY. Does nothing unless the app is really idle (no
        recording, transcription, agent request or speech in progress).
        Re-opening the wake word listener does NOT start a recording; a new,
        valid "Hey Jarvis" is required for that.
        """
        if self._closing or not self._voice_active:
            return
        if self.voice_state != VOICE_STANDBY:
            return

        self._voice_active = False
        if self._wake_listener_started:
            self.wake_listener.resume(guard_seconds=RESUME_GUARD_SECONDS)

    def _arm_wake_listener(self) -> None:
        """Called after the first successful manual mic use (never before)."""
        if not self._wake_listener_started:
            self._wake_listener_started = True
            self.wake_listener.start()

    def _set_listening_ui(self, listening: bool) -> None:
        if listening:
            self.mic_label.configure(fg=DANGER_COLOR)
            self.status_dot.configure(fg=DANGER_COLOR)
            self.status_label.configure(text=" Listening...")
        else:
            self.mic_label.configure(fg=MUTED_COLOR)
            self.status_dot.configure(fg=ONLINE_COLOR)
            self.status_label.configure(text=" Online")

    def _begin_recording(self, auto_stop_ms: int | None = None) -> bool:
        """Start recording. Returns False (and cleans up) if it can't."""
        if self._closing or self.voice_state != VOICE_STANDBY:
            return False

        self._begin_voice_session()

        try:
            self.recorder.start()
        except Exception as error:
            self._end_voice_session()
            self._add_bubble(f"I couldn't access the microphone: {error}", is_user=False)
            return False

        self._is_recording = True
        self._recording_token += 1
        self._set_listening_ui(True)

        if auto_stop_ms is not None:
            token = self._recording_token
            self.root.after(auto_stop_ms, lambda: self._finish_recording(token))

        return True

    def _toggle_recording(self) -> None:
        if self._closing:
            return

        if not self._is_recording:
            if self._begin_recording():
                self._arm_wake_listener()
        else:
            self._finish_recording()

    def _finish_recording(self, token: int | None = None) -> None:
        # A stale auto-stop timer (from an earlier recording) must not end
        # a newer recording.
        if token is not None and token != self._recording_token:
            return
        if not self._is_recording:
            return

        self._is_recording = False
        self._recording_token += 1
        self._set_listening_ui(False)

        try:
            audio_path = self.recorder.stop()
        except Exception:
            traceback.print_exc()
            audio_path = ""

        if audio_path:
            self._transcribing = True
            threading.Thread(
                target=self._transcribe_worker, args=(audio_path,), daemon=True
            ).start()
        else:
            self._end_voice_session()

    def _start_wake_recording(self) -> None:
        # Checked on the main thread, at the moment the event is handled: a
        # wake word is only honoured when truly in STANDBY. Duplicates that
        # queued up behind a recording that already started are ignored.
        if self._closing or self.voice_state != VOICE_STANDBY:
            return

        self.show()
        self._switch_view("Chat")
        self._begin_recording(auto_stop_ms=WAKE_RECORDING_MS)

    # ---- Background-thread entry points: NO Tkinter access allowed ----
    def _on_wake_word(self) -> None:
        self._post("wake")

    def _on_wake_error(self, message: str) -> None:
        self._post("wake_error", message)

    def _transcribe_worker(self, audio_path: str) -> None:
        try:
            text = transcribe(audio_path, cleanup=True)
        except Exception as error:
            self._post("transcription_error", str(error))
            return

        if text:
            self._post("transcript", text)
        else:
            self._post("transcription_empty")

    def _speak_worker(self, text: str) -> None:
        try:
            speak(text)
        except Exception:
            traceback.print_exc()
        finally:
            self._post("speech_done")

    def _run_agent(self, user_message: str, conversation_id: int, speak_response: bool) -> None:
        is_error = False
        try:
            response = self.agent.process(user_message, conversation_id)
        except Exception as error:
            response = f"Error: {error}"
            is_error = True

        self._post(
            "agent_response",
            {
                "text": response,
                "speak": speak_response,
                "is_error": is_error,
                "conversation_id": conversation_id,
            },
        )

        try:
            convo = self.agent.history_store.get_conversation(conversation_id)
            if convo and convo["title"] == "New Chat":
                title = self.agent.generate_title(user_message)
                self.agent.history_store.rename_conversation(conversation_id, title)
        except Exception:
            pass

    # ---- Tools view ----
    def _build_tools_view(self) -> None:
        tools_frame = tk.Frame(self.view_container, bg=BG_DARK)
        self.views["Tools"] = tools_frame

        tk.Label(tools_frame, text="Available Tools", fg=TEXT_COLOR, bg=BG_DARK, font=self.font_section).pack(anchor="w", padx=24, pady=(20, 4))
        tk.Label(
            tools_frame, text=f"Jarvis currently has {len(self.agent.tools)} tools it can call.",
            fg=MUTED_COLOR, bg=BG_DARK, font=self.font_card_sub,
        ).pack(anchor="w", padx=24, pady=(0, 16))

        canvas = tk.Canvas(tools_frame, bg=BG_DARK, highlightthickness=0)
        scrollbar = tk.Scrollbar(tools_frame, command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(24, 0))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        inner = tk.Frame(canvas, bg=BG_DARK)
        window = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(window, width=e.width - 24))

        for tool_def in self.agent.tools:
            func = tool_def["function"]
            card = tk.Frame(inner, bg=CARD_BG)
            card.pack(fill=tk.X, pady=6, padx=(0, 20), ipady=10)
            tk.Label(card, text=func["name"], fg=TEXT_COLOR, bg=CARD_BG, font=self.font_tool_name).pack(anchor="w", padx=16, pady=(4, 2))
            tk.Label(
                card, text=func.get("description", ""), fg=MUTED_COLOR, bg=CARD_BG,
                font=self.font_card_sub, wraplength=700, justify=tk.LEFT,
            ).pack(anchor="w", padx=16, pady=(0, 4))

    # ---- Settings view ----
    def _build_settings_view(self) -> None:
        settings_frame = tk.Frame(self.view_container, bg=BG_DARK)
        self.views["Settings"] = settings_frame

        tk.Label(settings_frame, text="Settings", fg=TEXT_COLOR, bg=BG_DARK, font=self.font_section).pack(anchor="w", padx=24, pady=(20, 16))

        card = tk.Frame(settings_frame, bg=CARD_BG)
        card.pack(fill=tk.X, padx=24, pady=6, ipady=12)
        tk.Label(card, text="All conversations", fg=TEXT_COLOR, bg=CARD_BG, font=self.font_tool_name).pack(anchor="w", padx=16, pady=(4, 2))
        tk.Label(
            card, text="This permanently deletes every chat Jarvis has stored.",
            fg=MUTED_COLOR, bg=CARD_BG, font=self.font_card_sub,
        ).pack(anchor="w", padx=16, pady=(0, 10))
        tk.Button(
            card, text="Delete all chats", command=self._clear_all_chats,
            bg=DANGER_COLOR, fg="white", relief=tk.FLAT, font=self.font_card_sub,
            padx=12, pady=6, cursor="pointinghand",
        ).pack(anchor="w", padx=16, pady=(0, 6))

        card2 = tk.Frame(settings_frame, bg=CARD_BG)
        card2.pack(fill=tk.X, padx=24, pady=6, ipady=12)
        tk.Label(card2, text="Voice", fg=TEXT_COLOR, bg=CARD_BG, font=self.font_tool_name).pack(anchor="w", padx=16, pady=(4, 2))
        tk.Label(
            card2,
            text=(
                'Click the microphone once to activate voice. After that, '
                'say "Hey Jarvis" any time to start listening again.'
            ),
            fg=MUTED_COLOR, bg=CARD_BG, font=self.font_card_sub, wraplength=500, justify=tk.LEFT,
        ).pack(anchor="w", padx=16, pady=(0, 10))

        card3 = tk.Frame(settings_frame, bg=CARD_BG)
        card3.pack(fill=tk.X, padx=24, pady=6, ipady=12)
        tk.Label(card3, text="Application", fg=TEXT_COLOR, bg=CARD_BG, font=self.font_tool_name).pack(anchor="w", padx=16, pady=(4, 2))
        tk.Button(
            card3, text="Quit Jarvis", command=self.shutdown,
            bg=ASSISTANT_BUBBLE, fg=TEXT_COLOR, relief=tk.FLAT, font=self.font_card_sub,
            padx=12, pady=6, cursor="pointinghand",
        ).pack(anchor="w", padx=16, pady=(6, 6))

    def _clear_all_chats(self) -> None:
        confirmed = messagebox.askyesno("Delete all chats", "This will permanently delete every conversation. Continue?")
        if not confirmed:
            return

        self.agent.history_store.clear_all()
        new_id = self.agent.history_store.create_conversation()
        self._load_conversation(new_id)

    # ---- Chats view ----
    def _build_chats_view(self) -> None:
        chats_frame = tk.Frame(self.view_container, bg=BG_DARK)
        self.views["Chats"] = chats_frame

        header_row = tk.Frame(chats_frame, bg=BG_DARK)
        header_row.pack(fill=tk.X, padx=24, pady=(20, 12))

        tk.Label(header_row, text="Chats", fg=TEXT_COLOR, bg=BG_DARK, font=self.font_section).pack(side=tk.LEFT)

        tk.Button(
            header_row, text="+ New Chat", command=self._new_chat,
            bg=ACCENT_COLOR, fg="white", relief=tk.FLAT, font=self.font_card_sub,
            padx=12, pady=4, cursor="pointinghand",
        ).pack(side=tk.RIGHT)

        canvas = tk.Canvas(chats_frame, bg=BG_DARK, highlightthickness=0)
        scrollbar = tk.Scrollbar(chats_frame, command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(24, 0))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.chats_inner = tk.Frame(canvas, bg=BG_DARK)
        window = canvas.create_window((0, 0), window=self.chats_inner, anchor="nw")
        self.chats_inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(window, width=e.width - 24))

    def _refresh_chats_view(self) -> None:
        for widget in self.chats_inner.winfo_children():
            widget.destroy()

        conversations = self.agent.history_store.list_conversations()

        for convo in conversations:
            row = tk.Frame(self.chats_inner, bg=CARD_BG)
            row.pack(fill=tk.X, pady=4, padx=(0, 20), ipady=8)

            is_current = convo["id"] == self.current_conversation_id
            title_color = ACCENT_COLOR if is_current else TEXT_COLOR

            title_label = tk.Label(
                row, text=convo["title"], fg=title_color, bg=CARD_BG,
                font=self.font_tool_name, cursor="pointinghand", anchor="w",
            )
            title_label.pack(side=tk.LEFT, padx=12, fill=tk.X, expand=True)
            title_label.bind("<Button-1>", lambda e, cid=convo["id"]: self._load_conversation(cid))

            delete_btn = tk.Label(row, text="\U0001F5D1", fg=DANGER_COLOR, bg=CARD_BG, cursor="pointinghand", font=("Helvetica Neue", 12))
            delete_btn.pack(side=tk.RIGHT, padx=(6, 12))
            delete_btn.bind("<Button-1>", lambda e, cid=convo["id"]: self._delete_conversation(cid))

            rename_btn = tk.Label(row, text="\u270E", fg=MUTED_COLOR, bg=CARD_BG, cursor="pointinghand", font=("Helvetica Neue", 12))
            rename_btn.pack(side=tk.RIGHT, padx=6)
            rename_btn.bind("<Button-1>", lambda e, cid=convo["id"]: self._rename_conversation(cid))

    def _new_chat(self) -> None:
        conversation_id = self.agent.history_store.create_conversation()
        self._load_conversation(conversation_id)
        self._refresh_chats_view()

    def _rename_conversation(self, conversation_id: int) -> None:
        new_title = simpledialog.askstring("Rename Chat", "New title:", parent=self.root)
        if new_title and new_title.strip():
            self.agent.history_store.rename_conversation(conversation_id, new_title.strip())
            self._refresh_chats_view()

    def _delete_conversation(self, conversation_id: int) -> None:
        confirmed = messagebox.askyesno("Delete chat", "Delete this conversation permanently?")
        if not confirmed:
            return

        self.agent.history_store.delete_conversation(conversation_id)

        if conversation_id == self.current_conversation_id:
            remaining = self.agent.history_store.list_conversations()
            if remaining:
                self._load_conversation(remaining[0]["id"])
            else:
                new_id = self.agent.history_store.create_conversation()
                self._load_conversation(new_id)

        self._refresh_chats_view()

    def _load_conversation(self, conversation_id: int) -> None:
        self.current_conversation_id = conversation_id

        for widget in self.messages_frame.winfo_children():
            widget.destroy()

        records = self.agent.history_store.get_full_history(conversation_id, limit=500)

        if not records:
            self._add_bubble(
                "Hello! I'm Jarvis, your personal AI assistant. How can I help you today?",
                is_user=False,
            )
            self._add_quick_actions()
        else:
            for record in records:
                self._add_bubble(record["content"], is_user=(record["role"] == "user"))

        self._switch_view("Chat")

    # ---- message rendering ----
    def _add_avatar(self, parent) -> None:
        avatar = tk.Canvas(parent, width=40, height=40, bg=BG_DARK, highlightthickness=0)
        avatar.pack(side=tk.LEFT, padx=(0, 10), anchor="n")
        draw_logo(avatar, 20, 20, 18)

    def _add_bubble(self, text: str, is_user: bool) -> None:
        row = tk.Frame(self.messages_frame, bg=BG_DARK)
        row.pack(fill=tk.X, padx=20, pady=8)

        timestamp = datetime.now().strftime("%I:%M %p")
        bubble_color = USER_BUBBLE if is_user else ASSISTANT_BUBBLE
        max_width = 420

        if is_user:
            wrapper = tk.Frame(row, bg=BG_DARK)
            wrapper.pack(side=tk.RIGHT)
        else:
            outer = tk.Frame(row, bg=BG_DARK)
            outer.pack(side=tk.LEFT)
            self._add_avatar(outer)
            wrapper = tk.Frame(outer, bg=BG_DARK)
            wrapper.pack(side=tk.LEFT)

        bubble_canvas = tk.Canvas(wrapper, bg=BG_DARK, highlightthickness=0)
        bubble_canvas.pack()

        pad = 14
        text_id = bubble_canvas.create_text(
            pad, pad, text=text, anchor="nw", fill="white" if is_user else TEXT_COLOR,
            font=self.font_body, width=max_width,
        )
        bubble_canvas.update_idletasks()
        bbox = bubble_canvas.bbox(text_id)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]

        rect_id = rounded_rect(bubble_canvas, 0, 0, text_w + pad * 2, text_h + pad * 2, radius=16, fill=bubble_color, outline="")
        bubble_canvas.tag_lower(rect_id, text_id)

        meta_text = f"{timestamp}  \u2713\u2713" if is_user else timestamp
        meta_anchor = "ne" if is_user else "nw"
        meta_x = text_w + pad * 2 - 4 if is_user else 4

        bubble_canvas.create_text(
            meta_x, text_h + pad * 2 + 12, text=meta_text, anchor=meta_anchor,
            fill=ACCENT_COLOR if is_user else MUTED_COLOR, font=self.font_time,
        )

        bubble_canvas.configure(width=text_w + pad * 2, height=text_h + pad * 2 + 20)
        self.root.after(10, self._scroll_to_bottom)

    def _add_quick_actions(self) -> None:
        row = tk.Frame(self.messages_frame, bg=BG_DARK)
        row.pack(fill=tk.X, padx=(70, 20), pady=(0, 10))

        for icon, label, kind, payload in QUICK_ACTIONS:
            pill = tk.Canvas(row, height=36, bg=BG_DARK, highlightthickness=0, cursor="pointinghand")
            pill.pack(side=tk.LEFT, padx=(0, 8))

            full_text = f"{icon}  {label}"
            text_id = pill.create_text(16, 18, text=full_text, anchor="w", fill=TEXT_COLOR, font=self.font_pill)
            bbox = pill.bbox(text_id)
            width = bbox[2] + 16

            rect_id = rounded_rect(pill, 0, 0, width, 36, radius=18, fill=PILL_BG, outline=BORDER_COLOR)
            pill.tag_lower(rect_id, text_id)
            pill.configure(width=width, height=36)

            pill.bind("<Button-1>", lambda event, k=kind, p=payload: self._handle_quick_action(k, p))

    def _handle_quick_action(self, kind: str, payload: str) -> None:
        if kind == "prefill":
            self.entry.delete(0, tk.END)
            self.entry.insert(0, payload)
            self.entry.focus_set()
            self.entry.icursor(tk.END)
        elif kind == "submit":
            self._submit_message(payload, speak_response=False)
        elif kind == "view":
            self._switch_view(payload)

    def _scroll_to_bottom(self) -> None:
        if self._closing:
            return
        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def _set_thinking(self, thinking: bool) -> None:
        self._is_thinking = thinking
        color = ACCENT_COLOR if thinking else ONLINE_COLOR
        text = " Thinking..." if thinking else " Online"
        self.status_dot.configure(fg=color)
        self.status_label.configure(text=text)

    def _on_submit(self, event=None) -> None:
        if self._is_thinking or self._closing:
            return
        user_message = self.entry.get().strip()
        if not user_message:
            return
        self.entry.delete(0, tk.END)
        self._submit_message(user_message, speak_response=False)

    def _submit_message(self, user_message: str, speak_response: bool) -> bool:
        """Returns True if the message was accepted for processing."""
        if self._closing or self._is_thinking:
            return False

        self._add_bubble(user_message, is_user=True)
        self._set_thinking(True)

        threading.Thread(
            target=self._run_agent,
            args=(user_message, self.current_conversation_id, speak_response),
            daemon=True,
        ).start()
        return True

    def _on_agent_response(self, payload: dict) -> None:
        self._set_thinking(False)

        # If the user switched chats while Jarvis was thinking, the reply is
        # already saved in its own conversation; don't draw it in this one.
        if payload["conversation_id"] == self.current_conversation_id:
            self._add_bubble(payload["text"], is_user=False)

        if payload["speak"] and not payload["is_error"]:
            self._is_speaking = True
            threading.Thread(
                target=self._speak_worker, args=(payload["text"],), daemon=True
            ).start()
        else:
            self._end_voice_session()

    # ---- window control ----
    def show(self) -> None:
        if self._closing:
            return
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()
        self.entry.focus_set()

    def hide(self) -> None:
        self.root.withdraw()

    def toggle(self) -> None:
        if self.root.state() == "withdrawn":
            self.show()
        else:
            self.hide()

    # ---- shutdown ----
    def _remove_status_item(self) -> None:
        item = getattr(self, "_status_item", None)
        if item is not None:
            NSStatusBar.systemStatusBar().removeStatusItem_(item)
            self._status_item = None

    def shutdown(self) -> None:
        """
        Fully quit Jarvis. Idempotent and main-thread only.

        Background threads are daemon threads and are NOT joined: we never
        wait for a slow model reply or a model download. They can no longer
        reach the GUI because _post() ignores everything once closing.
        """
        if self._closing:
            return
        self._closing = True

        cleanup_steps = (
            self.wake_listener.stop,
            self._cancel_recording,
            shutdown_speech,
            self._remove_status_item,
        )

        for step in cleanup_steps:
            try:
                step()
            except Exception:
                traceback.print_exc()

        try:
            self.root.quit()
        except tk.TclError:
            pass

    def _cancel_recording(self) -> None:
        self._is_recording = False
        self.recorder.cancel()

    def run(self) -> None:
        try:
            self.root.mainloop()
        finally:
            self.shutdown()
            try:
                self.root.destroy()
            except tk.TclError:
                pass


class MenuDelegate(NSObject):
    def setGui_(self, gui):
        self.gui = gui

    def showJarvis_(self, sender):
        self.gui.show()

    def quitApp_(self, sender):
        self.gui.shutdown()


def setup_menu_bar(gui: JarvisGUI) -> MenuDelegate:
    delegate = MenuDelegate.alloc().init()
    delegate.setGui_(gui)

    status_bar = NSStatusBar.systemStatusBar()
    status_item = status_bar.statusItemWithLength_(NSVariableStatusItemLength)
    status_item.setTitle_("Jarvis")

    menu = NSMenu.alloc().init()

    show_item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Show Jarvis", "showJarvis:", "")
    show_item.setTarget_(delegate)
    menu.addItem_(show_item)

    quit_item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Quit Jarvis", "quitApp:", "")
    quit_item.setTarget_(delegate)
    menu.addItem_(quit_item)

    status_item.setMenu_(menu)

    gui._status_item = status_item
    gui._menu = menu

    return delegate


def main() -> None:
    SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)

    gui = JarvisGUI()

    delegate = setup_menu_bar(gui)
    gui._menu_delegate = delegate

    # The microphone (and wake word listening) stays completely off until
    # the user clicks the mic button for the first time.
    gui.run()


if __name__ == "__main__":
    main()