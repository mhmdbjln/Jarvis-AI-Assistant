import platform
import subprocess


def get_system_info() -> str:
    """
    Return basic information about the current Mac.
    """

    try:
        macos_version = platform.mac_ver()[0]
        architecture = platform.machine()
        processor = platform.processor()

        memory_result = subprocess.run(
            ["sysctl", "-n", "hw.memsize"],
            capture_output=True,
            text=True,
            check=False,
        )

        if memory_result.returncode == 0:
            memory_bytes = int(memory_result.stdout.strip())
            memory_gb = round(memory_bytes / (1024 ** 3), 2)
        else:
            memory_gb = "Unknown"

        return (
            f"macOS version: {macos_version}\n"
            f"Architecture: {architecture}\n"
            f"Processor: {processor or 'Apple Silicon'}\n"
            f"RAM: {memory_gb} GB"
        )

    except Exception as error:
        return f"Failed to get system information: {error}"