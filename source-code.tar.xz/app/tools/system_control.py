import subprocess


def close_application(app_name: str) -> str:
    """
    Quit a macOS application by its name.

    Args:
        app_name: The exact name of the application to quit.
    """

    script = f'tell application "{app_name}" to quit'

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            return f"Closed application: {app_name}"

        error_message = result.stderr.strip()

        return f"Failed to close {app_name}: {error_message}"

    except Exception as error:
        return f"Unexpected error while closing {app_name}: {error}"


def set_volume(level: int) -> str:
    """
    Set the system output volume.

    Args:
        level: Volume level from 0 (mute) to 100 (max).
    """

    clamped_level = max(0, min(100, level))

    script = f"set volume output volume {clamped_level}"

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            return f"Volume set to {clamped_level}."

        error_message = result.stderr.strip()

        return f"Failed to set volume: {error_message}"

    except Exception as error:
        return f"Unexpected error while setting volume: {error}"


def get_volume() -> str:
    """Get the current system output volume."""

    script = "output volume of (get volume settings)"

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            return f"Current volume is {result.stdout.strip()}."

        error_message = result.stderr.strip()

        return f"Failed to get volume: {error_message}"

    except Exception as error:
        return f"Unexpected error while getting volume: {error}"