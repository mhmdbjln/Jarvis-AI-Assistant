import requests
from bs4 import BeautifulSoup
from ddgs import DDGS


def web_search(query: str, max_results: int = 5) -> str:
    """
    Search the web for current information using DuckDuckGo.

    Args:
        query: The search query.
        max_results: Maximum number of results to return.
    """

    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))

        if not results:
            return f"No web results found for: {query}"

        lines = []

        for index, result in enumerate(results, start=1):
            title = result.get("title", "Untitled")
            url = result.get("href", "")
            snippet = result.get("body", "")

            lines.append(f"{index}. {title}\n   {url}\n   {snippet}")

        return "\n\n".join(lines)

    except Exception as error:
        return f"Web search failed: {error}"


def fetch_url(url: str, max_chars: int = 3000) -> str:
    """
    Fetch a web page and extract its main readable text content.

    Args:
        url: The URL to fetch.
        max_chars: Maximum number of characters to return, to avoid
            overwhelming the model's context.
    """

    try:
        headers = {"User-Agent": "Mozilla/5.0 (Jarvis Assistant)"}

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code != 200:
            return f"Failed to fetch URL: HTTP {response.status_code}"

        soup = BeautifulSoup(response.text, "html.parser")

        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()

        text = soup.get_text(separator="\n")

        lines = [line.strip() for line in text.splitlines() if line.strip()]

        cleaned_text = "\n".join(lines)

        if len(cleaned_text) > max_chars:
            cleaned_text = cleaned_text[:max_chars] + "\n...(truncated)"

        if not cleaned_text:
            return "The page did not contain any readable text."

        return cleaned_text

    except requests.exceptions.RequestException as error:
        return f"Failed to fetch URL: {error}"
    except Exception as error:
        return f"Unexpected error while fetching URL: {error}"