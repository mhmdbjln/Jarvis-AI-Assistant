from app.storage.reminder_store import ReminderStore

_store = ReminderStore()


def add_reminder(text: str, due_at: str = "") -> str:
    """
    Add a new reminder for the user.

    Args:
        text: The content of the reminder.
        due_at: Optional description of when it's due (e.g. "tomorrow
            at 10am"). Leave empty if there is no specific time.
    """

    reminder_id = _store.add_reminder(
        text=text,
        due_at=due_at or None,
    )

    if due_at:
        return f"Reminder #{reminder_id} added: '{text}' (due: {due_at})."

    return f"Reminder #{reminder_id} added: '{text}'."


def list_reminders() -> str:
    """List all pending (not yet completed) reminders."""

    reminders = _store.list_reminders(include_done=False)

    if not reminders:
        return "There are no pending reminders."

    lines = []

    for reminder in reminders:
        if reminder["due_at"]:
            lines.append(
                f"#{reminder['id']}: {reminder['text']} "
                f"(due: {reminder['due_at']})"
            )
        else:
            lines.append(f"#{reminder['id']}: {reminder['text']}")

    return "\n".join(lines)


def complete_reminder(reminder_id: int) -> str:
    """
    Mark a reminder as completed.

    Args:
        reminder_id: The id of the reminder to mark as done.
    """

    updated = _store.complete_reminder(reminder_id)

    if updated:
        return f"Reminder #{reminder_id} marked as completed."

    return f"No reminder found with id #{reminder_id}."