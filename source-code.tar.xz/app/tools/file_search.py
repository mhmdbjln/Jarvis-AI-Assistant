import subprocess


def find_file(name: str, max_results: int = 10) -> str:
    """
    Search the Mac for files matching a given name using Spotlight.

    Args:
        name: The filename or part of the filename to search for.
        max_results: Maximum number of results to return.
    """

    try:
        result = subprocess.run(
            ["mdfind", name],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            error_message = result.stderr.strip()
            return f"Failed to search for file: {error_message}"

        paths = [
            line
            for line in result.stdout.splitlines()
            if line.strip()
        ]

        if not paths:
            return f"No files found matching: {name}"

        limited_paths = paths[:max_results]

        formatted = "\n".join(limited_paths)

        total_found = len(paths)
        shown = len(limited_paths)

        if total_found > shown:
            return (
                f"Found {total_found} results, showing the first "
                f"{shown}:\n{formatted}"
            )

        return f"Found {total_found} result(s):\n{formatted}"

    except Exception as error:
        return f"Unexpected error while searching for file: {error}"