from typing import Any, Callable

from app.tools.applications import open_application
from app.tools.clipboard import read_clipboard, write_clipboard
from app.tools.file_reader import read_file
from app.tools.file_search import find_file
from app.tools.memory import remember
from app.tools.ocr import read_screen_text
from app.tools.reminders import add_reminder, complete_reminder, list_reminders
from app.tools.screenshot import take_screenshot
from app.tools.system import get_system_info
from app.tools.system_control import close_application, get_volume, set_volume
from app.tools.system_monitor import (
    get_battery_status,
    get_cpu_usage,
    get_disk_space,
)
from app.tools.vision import look_at_screen
from app.tools.web import fetch_url, web_search
from app.tools.window_control import move_window


class ToolRegistry:
    """Registry for Jarvis tools."""

    def __init__(self) -> None:
        self.tools: dict[str, Callable[..., str]] = {
            "open_application": open_application,
            "get_system_info": get_system_info,
            "take_screenshot": take_screenshot,
            "look_at_screen": look_at_screen,
            "close_application": close_application,
            "set_volume": set_volume,
            "get_volume": get_volume,
            "read_clipboard": read_clipboard,
            "write_clipboard": write_clipboard,
            "find_file": find_file,
            "add_reminder": add_reminder,
            "list_reminders": list_reminders,
            "complete_reminder": complete_reminder,
            "read_screen_text": read_screen_text,
            "web_search": web_search,
            "fetch_url": fetch_url,
            "read_file": read_file,
            "get_battery_status": get_battery_status,
            "get_disk_space": get_disk_space,
            "get_cpu_usage": get_cpu_usage,
            "move_window": move_window,
            "remember": remember,
        }

    def execute(self, tool_name: str, arguments: dict[str, Any]) -> str:
        """Execute a registered tool."""
        tool = self.tools.get(tool_name)

        if tool is None:
            return f"Unknown tool: {tool_name}"

        try:
            return tool(**arguments)
        except Exception as error:
            return f"Tool execution error: {error}"