import subprocess
from pathlib import Path


def take_screenshot() -> str:
    """
    Take a screenshot of the current macOS screen.

    Returns:
        The path to the saved screenshot or an error message.
    """

    try:
        screenshot_dir = Path.home() / "Pictures" / "Jarvis"

        screenshot_dir.mkdir(parents=True, exist_ok=True)

        screenshot_path = screenshot_dir / "screenshot.png"

        result = subprocess.run(
            [
                "screencapture",
                "-x",
                str(screenshot_path),
            ],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            return f"Screenshot saved to: {screenshot_path}"

        error_message = result.stderr.strip()

        return f"Failed to take screenshot: {error_message}"

    except Exception as error:
        return f"Unexpected error while taking screenshot: {error}"