import subprocess
import tempfile
from pathlib import Path


_POSITIONS = {
    "left_half": lambda w, h: (0, 0, w // 2, h),
    "right_half": lambda w, h: (w // 2, 0, w, h),
    "top_half": lambda w, h: (0, 0, w, h // 2),
    "bottom_half": lambda w, h: (0, h // 2, w, h),
    "full_screen": lambda w, h: (0, 0, w, h),
    "center": lambda w, h: (w // 4, h // 4, (3 * w) // 4, (3 * h) // 4),
}


def _run_applescript(script: str) -> subprocess.CompletedProcess:
    """Run an AppleScript by writing it to a temp file and executing it."""

    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".scpt",
        delete=False,
    ) as temp_file:
        temp_file.write(script)
        script_path = temp_file.name

    try:
        result = subprocess.run(
            ["osascript", script_path],
            capture_output=True,
            text=True,
            check=False,
        )
    finally:
        Path(script_path).unlink(missing_ok=True)

    return result


def _get_screen_size() -> tuple[int, int]:
    """Get the usable screen width and height in pixels."""

    script = 'tell application "Finder" to get bounds of window of desktop'

    result = _run_applescript(script)

    parts = [int(value.strip()) for value in result.stdout.strip().split(",")]

    x1, y1, x2, y2 = parts

    return x2 - x1, y2 - y1


def move_window(app_name: str, position: str) -> str:
    """
    Move and resize an application's window to a predefined screen
    position.

    Args:
        app_name: The exact name of the application whose window
            should be moved.
        position: One of 'left_half', 'right_half', 'top_half',
            'bottom_half', 'full_screen', 'center'.
    """

    if position not in _POSITIONS:
        valid_options = ", ".join(_POSITIONS)
        return f"Unknown position '{position}'. Valid options: {valid_options}"

    try:
        width, height = _get_screen_size()
    except Exception as error:
        return f"Failed to determine screen size: {error}"

    left, top, right, bottom = _POSITIONS[position](width, height)

    script = f"""
tell application "System Events"
    tell process "{app_name}"
        set position of window 1 to {{{left}, {top}}}
        set size of window 1 to {{{right - left}, {bottom - top}}}
    end tell
end tell
"""

    try:
        result = _run_applescript(script)

        if result.returncode == 0:
            return f"Moved '{app_name}' window to {position}."

        error_message = result.stderr.strip()

        return f"Failed to move window: {error_message}"

    except Exception as error:
        return f"Unexpected error while moving window: {error}"