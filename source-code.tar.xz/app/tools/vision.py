from app.ai.vision_client import VisionClient
from app.tools.screenshot import take_screenshot


def look_at_screen(question: str = "Describe what is currently on the screen.") -> str:
    """
    Take a screenshot of the current screen and analyze it
    using the local vision model.
    """

    screenshot_result = take_screenshot()

    if not screenshot_result.startswith("Screenshot saved to: "):
        return screenshot_result

    image_path = screenshot_result.removeprefix("Screenshot saved to: ").strip()

    vision_client = VisionClient()

    return vision_client.analyze_image(
        image_path=image_path,
        prompt=question,
    )