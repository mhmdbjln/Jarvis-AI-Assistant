from pathlib import Path


def read_file(path: str, max_chars: int = 6000) -> str:
    """
    Read the text content of a local file.

    Args:
        path: Path to the file. Supports '~' for the home directory.
        max_chars: Maximum number of characters to return, to avoid
            overwhelming the model's context.
    """

    try:
        file_path = Path(path).expanduser()

        if not file_path.exists():
            return f"File not found: {path}"

        if not file_path.is_file():
            return f"Not a file: {path}"

        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return (
                f"Cannot read '{path}': it does not appear to be a "
                "text file (binary or unsupported encoding)."
            )

        if not content.strip():
            return f"The file '{path}' is empty."

        if len(content) > max_chars:
            truncated = content[:max_chars]
            return (
                f"{truncated}\n...(truncated, file is longer than "
                f"{max_chars} characters)"
            )

        return content

    except PermissionError:
        return f"Permission denied when trying to read: {path}"
    except Exception as error:
        return f"Unexpected error while reading file: {error}"