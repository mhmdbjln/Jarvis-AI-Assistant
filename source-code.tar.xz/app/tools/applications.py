import difflib
import subprocess
from pathlib import Path


_APP_DIRS = [
    Path("/Applications"),
    Path("/System/Applications"),
    Path.home() / "Applications",
]


def _list_installed_apps() -> list[str]:
    names = []
    for directory in _APP_DIRS:
        if directory.exists():
            for item in directory.glob("*.app"):
                names.append(item.stem)
    return names


def _resolve_app_name(requested: str) -> str:
    """
    Resolve a possibly mis-transcribed app name to the closest real
    installed application name (e.g. 'software' -> 'Safari').
    """

    installed = _list_installed_apps()

    if not installed:
        return requested

    matches = difflib.get_close_matches(requested, installed, n=1, cutoff=0.4)
    if matches:
        return matches[0]

    lowered = requested.lower()
    for name in installed:
        if name.lower().startswith(lowered) or lowered.startswith(name.lower()):
            return name

    return requested


def open_application(app_name: str) -> str:
    """Open a macOS application by its name (with fuzzy name correction)."""

    resolved_name = _resolve_app_name(app_name)

    try:
        result = subprocess.run(
            ["open", "-a", resolved_name],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            return f"Application '{resolved_name}' opened successfully."

        error_message = result.stderr.strip()
        return f"Failed to open {resolved_name}: {error_message}"

    except Exception as error:
        return f"Unexpected error while opening {resolved_name}: {error}"