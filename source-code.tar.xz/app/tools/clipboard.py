import subprocess


def read_clipboard() -> str:
    """Read the current content of the macOS clipboard."""

    try:
        result = subprocess.run(
            ["pbpaste"],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode == 0:
            content = result.stdout

            if not content.strip():
                return "The clipboard is currently empty."

            return content

        error_message = result.stderr.strip()

        return f"Failed to read clipboard: {error_message}"

    except Exception as error:
        return f"Unexpected error while reading clipboard: {error}"


def write_clipboard(text: str) -> str:
    """
    Write text to the macOS clipboard.

    Args:
        text: The text to copy to the clipboard.
    """

    try:
        result = subprocess.run(
            ["pbcopy"],
            input=text,
            text=True,
            capture_output=True,
            check=False,
        )

        if result.returncode == 0:
            return "Text copied to clipboard."

        error_message = result.stderr.strip()

        return f"Failed to write to clipboard: {error_message}"

    except Exception as error:
        return f"Unexpected error while writing to clipboard: {error}"