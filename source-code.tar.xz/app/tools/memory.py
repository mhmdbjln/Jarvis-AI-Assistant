from app.storage.profile_store import ProfileStore

_store = ProfileStore()


def remember(fact: str) -> str:
    """
    Permanently remember a durable fact about the user (their name,
    preferences, how they like Jarvis to behave, likes/dislikes) so it
    is available in all future conversations, not just this one.

    Args:
        fact: The fact to remember, written clearly and concisely.
    """

    _store.add_fact(fact)
    return f"Got it, I'll remember that: {fact}"