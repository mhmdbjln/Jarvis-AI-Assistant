import pytesseract
from PIL import Image

from app.tools.screenshot import take_screenshot


def read_screen_text() -> str:
    """
    Take a screenshot of the current screen and extract any visible
    text from it using OCR. Faster and more accurate than the vision
    model for reading exact text, error messages, or code on screen.
    """

    screenshot_result = take_screenshot()

    if not screenshot_result.startswith("Screenshot saved to: "):
        return screenshot_result

    image_path = screenshot_result.removeprefix(
        "Screenshot saved to: "
    ).strip()

    try:
        image = Image.open(image_path)

        text = pytesseract.image_to_string(image)

        cleaned_text = text.strip()

        if not cleaned_text:
            return "No readable text was found on the screen."

        return cleaned_text

    except Exception as error:
        return f"Failed to read screen text: {error}"