import psutil


def get_battery_status() -> str:
    """Get the current battery percentage and charging status."""

    try:
        battery = psutil.sensors_battery()

        if battery is None:
            return "No battery detected (this might be a desktop Mac)."

        status = "charging" if battery.power_plugged else "on battery"

        return f"Battery is at {battery.percent:.0f}% ({status})."

    except Exception as error:
        return f"Failed to get battery status: {error}"


def get_disk_space(path: str = "/") -> str:
    """
    Get free and total disk space for a given path.

    Args:
        path: The filesystem path to check. Defaults to the root
            volume.
    """

    try:
        usage = psutil.disk_usage(path)

        free_gb = usage.free / (1024**3)
        total_gb = usage.total / (1024**3)

        return (
            f"Disk space at '{path}': {free_gb:.1f} GB free of "
            f"{total_gb:.1f} GB total ({usage.percent}% used)."
        )

    except FileNotFoundError:
        return f"Path not found: {path}"
    except Exception as error:
        return f"Failed to get disk space: {error}"


def get_cpu_usage() -> str:
    """Get the current CPU usage percentage."""

    try:
        percent = psutil.cpu_percent(interval=1)

        return f"CPU usage is currently {percent}%."

    except Exception as error:
        return f"Failed to get CPU usage: {error}"