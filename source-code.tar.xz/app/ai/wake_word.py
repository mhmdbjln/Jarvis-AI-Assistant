import sys
import threading
import time
from typing import Callable

import openwakeword
from openwakeword.model import Model
import sounddevice as sd


SAMPLE_RATE = 16000
CHUNK_SIZE = 1280
WAKE_MODEL_NAME = "hey_jarvis_v0.1"

# --- Detection tuning -------------------------------------------------------
# A detection is a rising EDGE: the score must reach ACTIVATION_THRESHOLD for
# CONFIRM_CHUNKS consecutive chunks (one chunk = 80 ms) while the detector is
# "armed". After firing, the detector is only re-armed once the score has
# fallen back to RESET_THRESHOLD or lower. A score that merely stays high (or
# is still high from stale audio) can therefore never fire twice.
ACTIVATION_THRESHOLD = 0.5
RESET_THRESHOLD = 0.2
CONFIRM_CHUNKS = 2
COOLDOWN_SECONDS = 3.0


class WakeWordListener:
    """
    Listens for the 'Hey Jarvis' wake word.

    Lifecycle:
      * start()  loads the model in the background; it never opens the mic.
      * resume(guard_seconds) opens the mic stream (only if the model is
        loaded), re-arms the detector and ignores the mic for guard_seconds.
      * pause()  fully closes the mic stream.
      * stop()   is terminal: closes everything, later calls do nothing.

    Why resume() re-arms: openWakeWord scores audio from an internal rolling
    buffer. When the stream is closed and reopened, that buffer still holds
    the previous "Hey Jarvis" (or the tail of Jarvis's own voice), so the very
    first chunks after resume() can score high with nobody speaking. We reset
    the model, start un-armed, and require a fresh rising edge.

    All methods are idempotent and at most one mic stream is ever open.
    The on_wake / on_error callbacks run on background threads and must not
    touch the GUI directly (they should just enqueue an event).
    """

    def __init__(
        self,
        on_wake: Callable[[], None],
        on_error: Callable[[str], None] | None = None,
        *,
        clock: Callable[[], float] = time.monotonic,
        activation_threshold: float = ACTIVATION_THRESHOLD,
        reset_threshold: float = RESET_THRESHOLD,
        confirm_chunks: int = CONFIRM_CHUNKS,
        cooldown_seconds: float = COOLDOWN_SECONDS,
    ) -> None:
        if reset_threshold >= activation_threshold:
            raise ValueError("reset_threshold must be lower than activation_threshold")

        self.on_wake = on_wake
        self.on_error = on_error

        self._clock = clock
        self._activation_threshold = activation_threshold
        self._reset_threshold = reset_threshold
        self._confirm_chunks = max(1, confirm_chunks)
        self._cooldown_seconds = cooldown_seconds

        self._lock = threading.RLock()
        self._started = False
        self._stopped = False
        self._want_listening = False
        self._model: Model | None = None
        self._stream: sd.InputStream | None = None
        self._loader: threading.Thread | None = None
        self._reported_errors: set[str] = set()

        # Detector state. Mutated by the audio callback; (re)initialised by
        # _rearm_locked() only while no stream is open.
        self._armed = False
        self._consecutive_high = 0
        self._last_trigger = float("-inf")
        self._guard_until = float("-inf")

    @property
    def is_listening(self) -> bool:
        return self._stream is not None

    # ---- error reporting (each distinct message is reported once) ----
    def _report_error(self, message: str) -> None:
        with self._lock:
            if message in self._reported_errors:
                return
            self._reported_errors.add(message)

        print(message, file=sys.stderr)

        if self.on_error is not None:
            try:
                self.on_error(message)
            except Exception:
                pass

    # ---- detection logic ----
    def _process_score(self, score: float) -> None:
        """Edge-triggered detection with hysteresis. Runs on the audio thread."""

        if self._stopped or not self._want_listening:
            return

        now = self._clock()

        # Guard window: the model is still being fed (which flushes stale
        # audio out of its buffer) but nothing may arm or trigger.
        if now < self._guard_until:
            self._armed = False
            self._consecutive_high = 0
            return

        if score <= self._reset_threshold:
            self._armed = True
            self._consecutive_high = 0
            return

        if score < self._activation_threshold:
            self._consecutive_high = 0
            return

        self._consecutive_high += 1

        if not self._armed or self._consecutive_high < self._confirm_chunks:
            return

        # A confirmed rising edge. Consume it whether or not we fire, so a
        # score that stays high can never fire later (e.g. when the cooldown
        # expires): a new trigger needs the score to drop to the reset level.
        self._armed = False
        self._consecutive_high = 0

        if now - self._last_trigger < self._cooldown_seconds:
            return

        self._last_trigger = now

        try:
            self.on_wake()
        except Exception as error:
            print(f"Wake callback failed: {error}", file=sys.stderr)

    # ---- audio callback (runs on the audio thread) ----
    def _callback(self, indata, frames, time_info, status) -> None:
        model = self._model

        if model is None or self._stopped or not self._want_listening:
            return

        try:
            predictions = model.predict(indata[:, 0])
        except Exception as error:
            self._report_error(f"Wake word detection error: {error}")
            return

        self._process_score(max(predictions.values(), default=0.0))

    # ---- state / stream management (lock must be held) ----
    def _rearm_locked(self, guard_seconds: float = 0.0) -> None:
        """Forget all audio history; require a fresh rising edge to trigger."""

        self._armed = False
        self._consecutive_high = 0
        self._guard_until = max(
            self._guard_until, self._clock() + max(0.0, guard_seconds)
        )

        reset = getattr(self._model, "reset", None) if self._model is not None else None
        if callable(reset):
            try:
                reset()
            except Exception as error:
                self._report_error(f"Wake word model reset failed: {error}")

    def _open_stream_locked(self) -> None:
        if (
            self._stream is not None
            or self._stopped
            or not self._want_listening
            or self._model is None
        ):
            return

        stream = None
        try:
            stream = sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=1,
                dtype="int16",
                blocksize=CHUNK_SIZE,
                callback=self._callback,
            )
            stream.start()
        except Exception as error:
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass
            self._stream = None
            self._report_error(f"Microphone unavailable for wake word: {error}")
            return

        self._stream = stream

    def _close_stream_locked(self) -> None:
        stream, self._stream = self._stream, None

        if stream is None:
            return

        for close_step in (stream.stop, stream.close):
            try:
                close_step()
            except Exception:
                pass

    # ---- model loading (background thread) ----
    def _load_model(self) -> Model:
        try:
            return Model(wakeword_models=[WAKE_MODEL_NAME])
        except Exception:
            # Models may simply not be downloaded yet.
            openwakeword.utils.download_models()
            return Model(wakeword_models=[WAKE_MODEL_NAME])

    def _load_worker(self) -> None:
        try:
            model = self._load_model()
        except Exception as error:
            self._report_error(f"Wake word model failed to load: {error}")
            with self._lock:
                self._started = False  # allow a later start() to retry
            return

        with self._lock:
            if self._stopped:
                return  # stopped while loading: never reopen the mic

            self._model = model
            self._rearm_locked()
            self._open_stream_locked()  # no-op unless resume() was called

    # ---- public API ----
    def start(self) -> None:
        """Begin loading the model. Does NOT open the microphone."""

        with self._lock:
            if self._started or self._stopped:
                return

            self._started = True
            self._loader = threading.Thread(target=self._load_worker, daemon=True)
            self._loader.start()

    def pause(self) -> None:
        with self._lock:
            self._want_listening = False
            self._close_stream_locked()

    def resume(self, guard_seconds: float = 0.0) -> None:
        """
        Go back to STANDBY. Opens the mic (if closed), resets the model and
        detector state, and ignores the mic for guard_seconds so the tail of
        Jarvis's own voice can never be mistaken for a wake word.
        Resuming does not start any recording by itself.
        """

        with self._lock:
            if self._stopped:
                return

            self._want_listening = True

            if self._stream is None:
                # No stream is running, so nothing is calling model.predict()
                # concurrently: safe to reset the model here.
                self._rearm_locked(guard_seconds)
                self._open_stream_locked()
            else:
                self._guard_until = max(
                    self._guard_until, self._clock() + max(0.0, guard_seconds)
                )

    def stop(self) -> None:
        with self._lock:
            self._stopped = True
            self._want_listening = False
            self._close_stream_locked()
            self._model = None