from openai import OpenAI

from app.config.settings import settings


class OpenAIClient:
    """Handles communication with the OpenAI API."""

    def __init__(self) -> None:
        if not settings.OPENAI_API_KEY:
            raise RuntimeError(
                "OPENAI_API_KEY is not configured."
            )

        self.client = OpenAI(
            api_key=settings.OPENAI_API_KEY
        )

    def generate_response(self, user_message: str) -> str:
        """Send a message to the model and return its text response."""

        response = self.client.responses.create(
            model=settings.OPENAI_MODEL,
            input=user_message,
        )

        return response.output_text