from pathlib import Path

from ollama import chat

from app.config.settings import settings


class VisionClient:
    """Handles image understanding using a local vision model."""

    def __init__(self) -> None:
        self.model = settings.OLLAMA_VISION_MODEL

    def analyze_image(
        self,
        image_path: str,
        prompt: str,
    ) -> str:
        """
        Analyze an image using the local vision model.

        Args:
            image_path: Path to the image.
            prompt: Question or instruction about the image.

        Returns:
            The model's final answer.
        """

        image = Path(image_path)

        if not image.exists():
            return f"Image not found: {image_path}"

        try:
            response = chat(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": prompt,
                        "images": [str(image)],
                    }
                ],
                think=False,
                options={
                    "num_predict": 512,
                    "temperature": 0.2,
                    "num_ctx": 8192,
                },
            )

            content = response.message.content

            if content:
                return content.strip()

            return "The vision model returned an empty response."

        except Exception as error:
            return f"Vision analysis failed: {error}"