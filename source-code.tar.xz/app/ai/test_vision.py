from ollama import chat

from app.config.settings import settings


IMAGE_PATH = "/Users/mohammadbajelan/Pictures/Jarvis/screenshot.png"


def main() -> None:
    print("=" * 60)
    print("JARVIS RAW VISION TEST")
    print("=" * 60)
    print(f"Model: {settings.OLLAMA_VISION_MODEL}")
    print(f"Image: {IMAGE_PATH}")
    print()

    try:
        response = chat(
            model=settings.OLLAMA_VISION_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": (
                        "Describe this Mac screenshot in 3 to 5 complete "
                        "sentences. Identify the main application, visible "
                        "windows, and important readable text. "
                        "Do not use chain-of-thought or explain your reasoning. "
                        "Only provide the final answer."
                    ),
                    "images": [IMAGE_PATH],
                }
            ],
            think=False,
            options={
                "num_predict": 512,
                "temperature": 0.7,
                "num_ctx": 8192,
            },
        )

        print("RAW RESPONSE:")
        print("=" * 60)
        print(response)
        print("=" * 60)

        print()
        print("DONE REASON:")
        print(repr(response.done_reason))

        print()
        print("DONE:")
        print(repr(response.done))

        print()
        print("EVAL COUNT:")
        print(repr(response.eval_count))

        print()
        print("CONTENT:")
        print(repr(response.message.content))

        print()
        print("THINKING:")
        print(repr(response.message.thinking))

    except Exception as error:
        print()
        print("=" * 60)
        print("VISION ERROR")
        print("=" * 60)
        print(f"{type(error).__name__}: {error}")


if __name__ == "__main__":
    main()