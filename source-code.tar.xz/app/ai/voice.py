import os
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf
from faster_whisper import WhisperModel


SAMPLE_RATE = 16000

PIPER_MODEL = Path.home() / ".jarvis" / "piper" / "en_US-lessac-medium.onnx"
PIPER_TIMEOUT_SECONDS = 60

# Every temporary audio file Jarvis creates carries this prefix, and
# safe_remove() refuses to delete anything that does not.
TEMP_PREFIX = "jarvis_"

COMMON_APP_NAMES = (
    "Safari, Chrome, Terminal, Notes, Messages, Photos, Mail, Calendar, "
    "Finder, Spotify, Slack, WhatsApp, Telegram, Visual Studio Code, "
    "Xcode, Preview, Music, Maps, Reminders, System Settings, Calculator."
)

_model: WhisperModel | None = None
_model_lock = threading.Lock()


class TranscriptionError(Exception):
    """Raised when speech-to-text fails."""


# ---------------------------------------------------------------------------
# Temporary file helpers
# ---------------------------------------------------------------------------

def _make_temp_wav(kind: str) -> str:
    """Create an empty temp WAV file and return its path (handle closed)."""

    fd, path = tempfile.mkstemp(prefix=f"{TEMP_PREFIX}{kind}_", suffix=".wav")
    os.close(fd)
    return path


def safe_remove(path: str) -> None:
    """
    Delete a temp audio file created by Jarvis. Never raises, and only
    deletes files that (a) carry the Jarvis temp prefix and (b) live
    directly in the system temp directory, so user files are never touched.
    """

    if not path:
        return

    try:
        target = Path(path)

        if not target.name.startswith(TEMP_PREFIX):
            return

        if target.resolve().parent != Path(tempfile.gettempdir()).resolve():
            return

        target.unlink(missing_ok=True)
    except OSError as error:
        print(f"Could not remove temp file {path}: {error}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Speech-to-text
# ---------------------------------------------------------------------------

def _get_model() -> WhisperModel:
    global _model

    with _model_lock:
        if _model is None:
            _model = WhisperModel("small", device="cpu", compute_type="int8")

        return _model


class VoiceRecorder:
    """
    Records microphone audio until stopped, then writes a temp WAV file.

    start(), stop() and cancel() are safe to call in any order and any
    number of times.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frames: list[np.ndarray] = []
        self._recording = False
        self._stream: sd.InputStream | None = None

    @property
    def is_recording(self) -> bool:
        return self._recording

    def _callback(self, indata, frames, time_info, status) -> None:
        if self._recording:
            self._frames.append(indata.copy())

    def _release_locked(self) -> list[np.ndarray]:
        """Close the stream and hand back captured frames. Lock must be held."""

        self._recording = False
        stream, self._stream = self._stream, None
        frames, self._frames = self._frames, []

        if stream is not None:
            for close_step in (stream.stop, stream.close):
                try:
                    close_step()
                except Exception:
                    pass

        return frames

    def start(self) -> None:
        """Begin recording. Raises if the microphone cannot be opened."""

        with self._lock:
            if self._recording:
                return

            self._frames = []
            self._recording = True

            try:
                stream = sd.InputStream(
                    samplerate=SAMPLE_RATE, channels=1, callback=self._callback
                )
                self._stream = stream
                stream.start()
            except Exception:
                # Roll back to a clean, reusable state before re-raising.
                self._release_locked()
                raise

    def stop(self) -> str:
        """
        Stop recording and return the path of a temp WAV file, or "" if
        nothing was recorded (or the file could not be written).
        """

        with self._lock:
            frames = self._release_locked()

        if not frames:
            return ""

        path = ""
        try:
            audio = np.concatenate(frames, axis=0)
            path = _make_temp_wav("rec")
            sf.write(path, audio, SAMPLE_RATE)
            return path
        except Exception as error:
            print(f"Failed to save recording: {error}", file=sys.stderr)
            safe_remove(path)
            return ""

    def cancel(self) -> None:
        """Stop recording and discard everything (no file is written)."""

        with self._lock:
            self._release_locked()


def transcribe(audio_path: str, cleanup: bool = False) -> str:
    """
    Transcribe a WAV file with a local Whisper model.

    Raises TranscriptionError on failure. If cleanup is True, the file is
    deleted afterwards (success or failure) -- only Jarvis temp files are
    ever deleted, see safe_remove().
    """

    try:
        model = _get_model()
        segments, _ = model.transcribe(
            audio_path,
            language="en",
            initial_prompt=(
                "Commands to a personal Mac assistant named Jarvis. "
                "Common application names mentioned: " + COMMON_APP_NAMES
            ),
        )
        return " ".join(segment.text for segment in segments).strip()
    except Exception as error:
        raise TranscriptionError(str(error)) from error
    finally:
        if cleanup:
            safe_remove(audio_path)


# ---------------------------------------------------------------------------
# Text-to-speech
# ---------------------------------------------------------------------------

_speech_lock = threading.Lock()
_current_process: subprocess.Popen | None = None
_speech_shutdown = threading.Event()


def shutdown_speech() -> None:
    """Permanently stop speech: terminate any playback and refuse new ones."""

    _speech_shutdown.set()

    with _speech_lock:
        process = _current_process

    if process is not None:
        try:
            process.terminate()
        except Exception:
            pass


def _run_tracked(cmd: list[str], input_text: str | None = None,
                 timeout: float | None = None) -> int:
    """Run a command whose process can be terminated by shutdown_speech()."""

    global _current_process

    with _speech_lock:
        if _speech_shutdown.is_set():
            return -1

        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE if input_text is not None else None,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        _current_process = process

    try:
        process.communicate(input=input_text, timeout=timeout)
        return process.returncode
    except subprocess.TimeoutExpired:
        process.kill()
        process.communicate()
        return -1
    finally:
        with _speech_lock:
            if _current_process is process:
                _current_process = None

        # Never leave an orphaned player/synthesiser behind, whatever
        # interrupted communicate() (timeout, shutdown, unexpected error).
        if process.poll() is None:
            try:
                process.kill()
                process.wait(timeout=2)
            except Exception:
                pass


def speak(text: str) -> None:
    """
    Speak text aloud with a local Piper voice, falling back to macOS 'say'.
    The temporary Piper WAV is always removed once playback is finished.
    """

    if not text.strip():
        return

    if PIPER_MODEL.exists():
        output_wav = ""
        try:
            output_wav = _make_temp_wav("tts")
            code = _run_tracked(
                ["piper", "--model", str(PIPER_MODEL), "--output_file", output_wav],
                input_text=text,
                timeout=PIPER_TIMEOUT_SECONDS,
            )

            if code == 0:
                _run_tracked(["afplay", output_wav])
                return
        except Exception:
            pass
        finally:
            safe_remove(output_wav)

    if _speech_shutdown.is_set():
        return

    try:
        _run_tracked(["say", text])
    except Exception:
        pass