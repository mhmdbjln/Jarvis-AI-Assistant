from typing import Any

from ollama import chat

from app.config.settings import settings


class OllamaClient:
    """Handles communication with the local Ollama model."""

    def __init__(self) -> None:
        self.model = settings.OLLAMA_MODEL

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        """Send messages to Ollama."""
        return chat(
            model=self.model,
            messages=messages,
            tools=tools or [],
            think=True,
            options={
                "temperature": 0.3,
                "num_ctx": 8192,
            },
        )