from typing import Any

from app.ai.ollama_client import OllamaClient
from app.storage.conversation_store import ConversationStore
from app.storage.profile_store import ProfileStore
from app.tools.registry import ToolRegistry


class JarvisAgent:
    """Core AI agent for Jarvis."""

    HISTORY_LIMIT = 20

    RAW_OUTPUT_TOOLS = {"read_screen_text"}

    BASE_SYSTEM_PROMPT = (
        "You are Jarvis, a personal AI assistant running locally on the "
        "user's own Mac. You are not a public chatbot; you serve only "
        "this one user, and everything they tell you (their name, "
        "preferences, plans) is their own personal information about "
        "themselves, shared voluntarily and stored locally. Answer such "
        "questions directly and naturally, without refusing or adding "
        "privacy disclaimers. Always respond in English, regardless of "
        "what language the user writes in. Use the available tools when "
        "they are relevant to the request.\n\n"
        "Never assume that a previous action (like opening or closing an "
        "application) still holds true just because a past message in "
        "this conversation claimed it happened. The real state of the "
        "Mac can change at any time outside this conversation (the user "
        "may have closed an app manually, for example). Whenever the "
        "user asks you to perform an action or check a current state, "
        "always call the appropriate tool again to get fresh, accurate "
        "information rather than relying on conversation history.\n\n"
        "The user's messages may come from voice transcription and can "
        "contain minor speech-to-text errors, especially for app or "
        "product names that sound similar to other words. Use context "
        "and common sense to infer the most likely intended meaning "
        "before acting.\n\n"
        "If the user shares a durable personal fact about themselves "
        "(their name, occupation, a lasting preference for how you "
        "should respond or behave, a like or dislike), call the "
        "'remember' tool to store it permanently. Do not call remember "
        "for temporary, one-off, or already-known information."
    )

    def __init__(self) -> None:
        self.ai = OllamaClient()
        self.tool_registry = ToolRegistry()
        self.history_store = ConversationStore()
        self.profile_store = ProfileStore()

        self.tools = [
            {
                "type": "function",
                "function": {
                    "name": "open_application",
                    "description": "Open a macOS application by its name.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "app_name": {
                                "type": "string",
                                "description": (
                                    "The name of the macOS application to "
                                    "open. May contain minor transcription "
                                    "errors if it came from voice input."
                                ),
                            }
                        },
                        "required": ["app_name"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "get_system_info",
                    "description": (
                        "Get basic information about the Mac, including "
                        "macOS version, architecture, processor and RAM."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "take_screenshot",
                    "description": (
                        "Take a screenshot of the current Mac screen "
                        "and save it to the Jarvis screenshots folder."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "look_at_screen",
                    "description": (
                        "Take a screenshot of the current screen and "
                        "use a vision model to describe or answer a "
                        "question about what is visible on it."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "question": {
                                "type": "string",
                                "description": "The question to ask about the screen.",
                            }
                        },
                        "required": [],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "close_application",
                    "description": "Quit a macOS application by its name.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "app_name": {
                                "type": "string",
                                "description": "The name of the macOS application to quit.",
                            }
                        },
                        "required": ["app_name"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "set_volume",
                    "description": "Set the system output volume to a specific level.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "level": {
                                "type": "integer",
                                "description": "Volume level from 0 (mute) to 100 (max).",
                            }
                        },
                        "required": ["level"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "get_volume",
                    "description": "Get the current system output volume.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "read_clipboard",
                    "description": "Read and return the current text content of the macOS clipboard.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "write_clipboard",
                    "description": "Copy the given text to the macOS clipboard.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {"type": "string", "description": "The text to copy."}
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "find_file",
                    "description": "Search the Mac for files whose name matches the given text.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Filename to search for."}
                        },
                        "required": ["name"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "add_reminder",
                    "description": "Add a new reminder for the user to be recalled later.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {"type": "string", "description": "The content of the reminder."},
                            "due_at": {
                                "type": "string",
                                "description": "Optional description of when it's due.",
                            },
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "list_reminders",
                    "description": "List all pending (not yet completed) reminders.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "complete_reminder",
                    "description": "Mark a reminder as completed, given its id.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "reminder_id": {"type": "integer", "description": "The id of the reminder."}
                        },
                        "required": ["reminder_id"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "read_screen_text",
                    "description": (
                        "Take a screenshot and extract exact visible text "
                        "from the screen using OCR."
                    ),
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "web_search",
                    "description": "Search the web for current information.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "The search query."}
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "fetch_url",
                    "description": "Fetch a specific web page by URL and extract its readable text.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "url": {"type": "string", "description": "The URL to fetch."}
                        },
                        "required": ["url"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "read_file",
                    "description": "Read the text content of a local file on the Mac, given its path.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "Path to the file."}
                        },
                        "required": ["path"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "get_battery_status",
                    "description": "Get the current battery percentage and charging status.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "get_disk_space",
                    "description": "Get free and total disk space for the main volume or a path.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "Filesystem path to check."}
                        },
                        "required": [],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "get_cpu_usage",
                    "description": "Get the current CPU usage percentage.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "move_window",
                    "description": (
                        "Move and resize an application's window to a predefined "
                        "screen position: left_half, right_half, top_half, "
                        "bottom_half, full_screen, or center."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "app_name": {"type": "string", "description": "Application name."},
                            "position": {"type": "string", "description": "Target position."},
                        },
                        "required": ["app_name", "position"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "remember",
                    "description": (
                        "Permanently remember a durable fact about the user "
                        "(name, occupation, lasting preferences, likes/dislikes) "
                        "for use in all future conversations."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "fact": {"type": "string", "description": "The fact to remember."}
                        },
                        "required": ["fact"],
                    },
                },
            },
        ]

    def _build_system_prompt(self) -> str:
        facts = self.profile_store.get_facts()
        prompt = self.BASE_SYSTEM_PROMPT

        if facts:
            facts_block = "\n".join(f"- {fact}" for fact in facts)
            prompt += (
                "\n\nHere is what you know about the user from previous "
                "conversations (treat this as reliable background, not "
                "something to repeat unprompted unless relevant):\n"
                + facts_block
            )

        return prompt

    def generate_title(self, user_message: str) -> str:
        """Generate a short title for a new conversation based on its first message."""

        try:
            response = self.ai.chat(
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Generate a concise, 3 to 6 word title summarizing "
                            "this user's request. Respond with only the title, "
                            "no punctuation, no quotes."
                        ),
                    },
                    {"role": "user", "content": user_message},
                ],
            )

            title = (response.message.content or "").strip().strip('"')
            return title[:60] if title else "New Chat"

        except Exception:
            return "New Chat"

    def process(self, user_message: str, conversation_id: int) -> str:
        """Process a user message within a specific conversation."""

        history = self.history_store.get_history(
            conversation_id, limit=self.HISTORY_LIMIT
        )

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": self._build_system_prompt()},
            *history,
            {"role": "user", "content": user_message},
        ]

        response = self.ai.chat(messages=messages, tools=self.tools)
        message = response.message

        final_content: str

        if not message.tool_calls:
            final_content = message.content
        else:
            raw_result: str | None = None

            for tool_call in message.tool_calls:
                tool_name = tool_call.function.name
                arguments = tool_call.function.arguments

                result = self.tool_registry.execute(tool_name, arguments)

                if tool_name in self.RAW_OUTPUT_TOOLS:
                    raw_result = result

                messages.append(
                    {
                        "role": "assistant",
                        "tool_calls": [
                            {"function": {"name": tool_name, "arguments": arguments}}
                        ],
                    }
                )
                messages.append({"role": "tool", "content": result})

            if raw_result is not None:
                final_content = raw_result
            else:
                final_response = self.ai.chat(messages=messages)
                final_content = final_response.message.content

        self.history_store.add_message(conversation_id, "user", user_message)
        self.history_store.add_message(conversation_id, "assistant", final_content)

        return final_content