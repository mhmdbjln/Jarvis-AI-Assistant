import os

from dotenv import load_dotenv


load_dotenv()


class Settings:
    """Application-wide configuration."""

    APP_NAME: str = "JARVIS"
    APP_VERSION: str = "0.1.0"

    # OpenAI
    OPENAI_API_KEY: str | None = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL: str = "gpt-5.6-luna"

    # Ollama
    OLLAMA_BASE_URL: str = "http://localhost:11434"

    # Main language model
    OLLAMA_MODEL: str = "qwen3:8b"

    # Vision model
    OLLAMA_VISION_MODEL: str = "qwen2.5vl:7b"


settings = Settings()